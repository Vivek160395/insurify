export class PolicyDetails {
      constructor(
     premiums :number,
     durations:number,
     sumInsure:number,
     adults1   :number,
     adults2   :number,
     adults3   :number,
     kids     :number,
     minSalary:number,
     maxSalary:number,
     modelsAllowed:string
  ){}
}

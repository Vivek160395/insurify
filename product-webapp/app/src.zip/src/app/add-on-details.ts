export class AddOnDetails {
      constructor(
    addOnName        :string,
    addOnDescription :string,
    addOnPremiums    :number
  ){}
}

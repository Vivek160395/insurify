export class PolicyBenefits {
      constructor(
    brief      :string,
    description:string
  ){}
}

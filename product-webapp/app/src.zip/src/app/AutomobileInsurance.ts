export class AutomobileInsurance{
    constructor(
        public vehicleRegistrationNumber:string,
        public category:string,
        public engineNumber:string,
        public chassisNumber:string,
        public model:string,
    ){}
}
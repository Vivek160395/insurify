

export class User {
        emailId!:string;
        password!:string;
        userType!: string;

        

}

import { PolicyAdvsior } from './policy-advsior';

describe('PolicyAdvsior', () => {
  it('should create an instance', () => {
    expect(new PolicyAdvsior()).toBeTruthy();
  });
});

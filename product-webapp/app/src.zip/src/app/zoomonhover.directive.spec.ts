import { ZoomonhoverDirective } from './zoomonhover.directive';

describe('ZoomonhoverDirective', () => {
  it('should create an instance', () => {
    const directive = new ZoomonhoverDirective();
    expect(directive).toBeTruthy();
  });
});

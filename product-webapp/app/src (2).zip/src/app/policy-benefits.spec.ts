import { PolicyBenefits } from './policy-benefits';

describe('PolicyBenefits', () => {
  it('should create an instance', () => {
    expect(new PolicyBenefits()).toBeTruthy();
  });
});

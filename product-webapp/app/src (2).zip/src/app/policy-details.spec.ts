import { PolicyDetails } from './policy-policyDetails';

describe('PolicyDetails', () => {
  it('should create an instance', () => {
    expect(new PolicyDetails()).toBeTruthy();
  });
});

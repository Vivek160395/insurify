export class Payment {

  // name: any;
    // email: any;
    // phone: any;
    // amount: any;
    // currency: any;
    // policyId: any;


}

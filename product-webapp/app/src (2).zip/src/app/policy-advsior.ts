import { LoginComponent } from "./login/login.component";

export class PolicyAdvsior {
    name!:string;
    gender!: string;
    dateOfBirth!: string;
    phoneNumber!: string;
    aadharNo!: Number;

    panNo!: string;

    YearsOfExperience!: Number;

    // List<String> category;

    category!: string[];
    profilePic!: any;


}


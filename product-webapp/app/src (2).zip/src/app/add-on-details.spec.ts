import { AddOnDetails } from './add-on-policyDetails';

describe('AddOnDetails', () => {
  it('should create an instance', () => {
    expect(new AddOnDetails()).toBeTruthy();
  });
});

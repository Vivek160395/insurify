export class Claim {
    customerPolicyId:string="";
    insurancePolicyId:string ="";
    email:string="";
    claimAmount:number=0;
    claimDate:string='';

}
